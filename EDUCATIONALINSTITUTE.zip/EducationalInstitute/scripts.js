document.addEventListener("DOMContentLoaded", function () {
    const form = document.querySelector("form");
    const successMessage = document.getElementById("success-message");

    form.addEventListener("submit", function (event) {
        event.preventDefault();
        // Here you can add AJAX if needed for form submission without page reload.

        // Simulate form submission for demo purposes
        successMessage.textContent = "Thank you for contacting us!";
        form.reset();
    });
});
